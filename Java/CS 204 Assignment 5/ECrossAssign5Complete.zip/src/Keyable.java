/**
 * Used for extracting the key from an object
 * @author Professor Myers
 *
 */
public interface Keyable <T> {
	public String getKey();

}
