/**Assignment 5, Fall 2014: CurlerPosition Class 
 * Creates enumerated type called CurlerPosition with values of "SKIP",
 * "THROWER", AND "SWEEPER"
 * 
 * @author Ebony Cross
 * 
 */
enum CurlerPosition { SKIP, THROWER, SWEEPER}
